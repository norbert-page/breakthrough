﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BreakthroughWPF
{
    public enum PiecesColor
    {
        White,
        Black,
        None
    }
}
