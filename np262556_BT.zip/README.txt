Aplikacja wymaga kilku us�ug niedawno wprowadzonych przez Microsoft, dlatego prosz� testowa� pod Windows Vista z najnowszymi �atami, gdy� przy wcze�niejszych wersjach mog� by� problemy.

Prosz� wy��czy� firewall systemowy.

Aplikacja wymaga sieci IPv6 lub tunelowania Teredo, kt�re domy�lnie jest wy��czone np. w Windows XP.
Musi by� aktywna w windowsie us�uga netTcpPortSharing (w wer. PL mo�e mie� inn� nazw�) i us�ugi zwi�zane z PNRP (Peer Name Resolution Protocol).

W windowsie mog� pom�c nast�puj�ce polecenia (prosz� najpierw spr�bowa� zwyczajnie odpali�):
netsh interface ipv6 install
netsh interface ipv6 set teredo client

netsh interface teredo set state client
netsh interface teredo show state

netsh p2p pnrp peer set machinename publish=start autopublish=enable
netsh p2p pnrp peer show machinename

Nast�puj�ce polecenie powinno wy�wietli� chmur� "Global" po starcie aplikacji, gdy zacznie si� szukanie host�w, w przeciwnym przypadku co� jest nie tak:
netsh p2p pnrp cloud show list

Je�eli wszystko dobrze jest skonfigurowane i jest po��czenie z internetem, to wykrywanie host�w powinno dzia�a� globalnie, a nie tylko w sieci lokalnej.

Testowany na Windows Vista SP1 Business Edition EN z najnowszymi �atami, kompilowane pod MS Visual Studio 2008 SP1 z najnowszymi �atami.
Program nie kompiluje si� na starszych wersjach Visual Studio (bez SP).

Program korzysta z pliku konfiguracyjnego App.config, gdzie jest zapisany wzorzec adresu z MeshID i domy�lny port. Mo�na uruchomi� kilka instancji aplikacji na jednym komputerze - u�ywaj� wtedy one tego samego portu, jednak ze wzgl�du na wykorzystanie wsp�dzielenia portu powinny dzia�a� bez problemu (przetestowane) (inny jest endpoint, ko�czy si� identyfikatorem u�ytkownika i doklejonym na ko�cu losowym �ancuchem znak�w).

Prosz� o cierpliwo�� podczas wyszukiwania host�w, jednym razem mo�e zadzia�a� od razu, a innym razem mo�e trwa� d�u�ej.

Je�eli b�dzie Pan testowa� na jednym komputerze, to prosz� pami�ta�, �e mo�na zmienia� rozmiar okna g��wnego gry oraz chowa� ca�y prawy panel z opcjami :)

Norbert Pionka